const mysql = require('mysql');

const express = require('express');

const app=express();

const bodyParser = require('body-parser');




app.set('view engine','ejs');

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({extended:true}));




const connection = mysql.createConnection({

host: 'localhost',

user: 'root',

password: 'root',

database: 'library'

});




app.get('/register',(req,res)=>{

res.render('register')

})

app.get('/sign-up',(req,res)=>{

    res.render('sign-up')
    
    })

app.get('/login',(req,res)=>{

    res.render('login')
        
    })
    app.get('/user_home',(req,res)=>{

        res.render('user_home')
            
        })

    
    


connection.connect((error) => {
if (error) {
 console.error('Error connecting to database:', error);
} else {
console.log('Connected to database');
}

});

app.post('/login',notauthenticated, (req, res) => {

    const email = req.body.email;
    
    const password = req.body.password;});

app.get('/user/home',(req,res)=>{

    res.render('user_home')
    
    })
    
    connection.connect((error) => {
    
    if (error) {
    console.error('Error connecting to database:', error);
    } else {
    console.log('Connected to database');
    }
    });



app.post('/register', (req, res) => {
const { first_name, last_name, email, password } = req.body;
connection.query(
'INSERT INTO users (first_name, last_name, email, password) VALUES (?, ?, ?, ?)',
[first_name, last_name, email, password],
(err, results) => {
if (err) {
console.error(err);
res.status(500).send('Error registering user');
} else {
res.status(200).send('User registered successfully');
}
}
);
});


  // Start the server
app.listen(3000, () => {

console.log('Server started on port 3000');
});