#Build a quiz game that allows users to answer multiple-choice questions and keeps track of their score.
# You can use a predefined set of questions and answers and store them in a text file or adatabase.

