#Write a program that takes a list of numbers and returns a new list with
#only the prime numbers.
