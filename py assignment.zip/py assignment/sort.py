


def sort_strings(strings):
    
    return sorted(strings)

string_list = input("Enter a list of strings, separated by commas: ").split(",")

sorted_strings = sort_strings(string_list)

print("Sorted strings:", sorted_strings)
