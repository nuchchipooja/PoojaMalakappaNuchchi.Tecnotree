#A simple example of a lambda function that squares a number:

square = lambda x: x**2

# call the lambda function
num= float(input("Enter the num: "))
result=square(num)

# print the result
print(result)